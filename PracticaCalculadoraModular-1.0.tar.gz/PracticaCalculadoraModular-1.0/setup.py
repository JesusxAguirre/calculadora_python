from setuptools import setup


setup(
name="PracticaCalculadoraModular",
version="1.0",
description="Calculadora de suma, resta, multiplicacion",
author="Jesus Aguirre Bastidas",
author_mail="99jesus.aguirre@gmail.com",
url="",
packages=["calculadora","calculadora.calculadoraModular."]
)